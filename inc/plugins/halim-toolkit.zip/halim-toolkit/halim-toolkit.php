<?php

/**
 * Plugin Name:       Halim Toolkit
 * Plugin URI:        https://itanvir.net/plugins/halim-toolkit/
 * Description:       Halim toolkit plugin only for Halim Wordpress Theme.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      8.0
 * Author:            iTanvir
 * Author URI:        https://itanvir.net/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       halim-toolkit
 * Domain Path:       /languages
 */



/**
 * Register Custom Post Type
 */
add_action('init', 'halim_theme_custom_post');
function halim_theme_custom_post() {
  // Register Custom Post for Slider
  register_post_type(
    'slider',
    array(
      'labels' => array(
        'name' => __('Sliders', 'halim'),
        'singular_name' => __('Slider', 'halim'),
        'add_new' => __('Add New Slide', 'halim'),
        'add_new_item' => __('Add New Slide', 'halim'),
      ),
      'supports' => array('title', 'editor', 'thumbnail'),
      'public'       => false,
      'show_ui'      => true,
      'show_in_rest' => true,
      'menu_icon'    => 'dashicons-slides',
    )
  );

  // Register Custom Post for Services
  register_post_type(
    'services',
    array(
      'labels' => array(
        'name' => __('Services', 'halim'),
        'singular_name' => __('Service', 'halim'),
        'add_new' => __('Add New Service', 'halim'),
        'add_new_item' => __('Add New Service', 'halim'),
      ),
      'supports' => array('title', 'editor'),
      'public'       => false,
      'show_ui'      => true,
      'show_in_rest' => true,
      'menu_icon'    => 'dashicons-admin-generic',
    )
  );

  // Register Custom Post for Counters
  register_post_type(
    'counters',
    array(
      'labels' => array(
        'name' => __('Counters', 'halim'),
        'singular_name' => __('Counter', 'halim'),
        'add_new' => __('Add New Counter', 'halim'),
        'add_new_item' => __('Add New Counter', 'halim'),
      ),
      'supports' => array('title'),
      'public'       => false,
      'show_ui'      => true,
      'show_in_rest' => false,
      'menu_icon'    => 'dashicons-networking',
    )
  );

  // Register Custom Post for Teams
  register_post_type(
    'teams',
    array(
      'labels' => array(
        'name' => __('Teams', 'halim'),
        'singular_name' => __('Team', 'halim'),
        'add_new' => __('Add New Member', 'halim'),
        'add_new_item' => __('Add New Member', 'halim'),
      ),
      'supports' => array('title', 'thumbnail'),
      'public'       => false,
      'show_ui'      => true,
      'show_in_rest' => false,
      'menu_icon'    => 'dashicons-groups',
    )
  );

  // Register Custom Post for Testimonials
  register_post_type(
    'testimonials',
    array(
      'labels' => array(
        'name' => __('Testimonials', 'halim'),
        'singular_name' => __('Testimonial', 'halim'),
        'add_new' => __('Add New Testimonial', 'halim'),
        'add_new_item' => __('Add New Testimonial', 'halim'),
      ),
      'supports' => array('title', 'editor', 'thumbnail'),
      'public'       => false,
      'show_ui'      => true,
      'show_in_rest' => false,
      'menu_icon'    => 'dashicons-testimonial',
    )
  );

  // Register Custom Post for Portfolio
  register_post_type(
    'portfolios',
    array(
      'labels' => array(
        'name' => __('Portfolios', 'halim'),
        'singular_name' => __('Portfolio', 'halim'),
        'add_new' => __('Add New Portfolio', 'halim'),
        'add_new_item' => __('Add New Portfolio', 'halim'),
      ),
      'supports' => array('title', 'editor', 'thumbnail'),
      'public'       => true,
      'show_ui'      => true,
      'show_in_rest' => false,
      'menu_icon'    => 'dashicons-portfolio',
    )
  );

  register_taxonomy('portfolio_cat', 'portfolios', [
    'labels' => [
      'name'              => __('Categories', 'halim'),
      'singular_name'     => __('Category', 'halim'),
      'add_new_item'      => __('Add New Category', 'halim'),
    ],
    'hierarchical'      => true,
    'public'            => false,
    'show_ui'           => true,
    'show_admin_column' => true,
  ]);


  // Register Custom Post for Galleries
  register_post_type(
    'galleries',
    array(
      'labels' => array(
        'name' => __('Galleries', 'halim'),
        'singular_name' => __('Gallery', 'halim'),
        'add_new' => __('Add New Gallery', 'halim'),
        'add_new_item' => __('Add New Gallery', 'halim'),
      ),
      'supports' => array('title', 'thumbnail'),
      'public'       => false,
      'show_ui'      => true,
      'show_in_rest' => false,
      'menu_icon'    => 'dashicons-format-gallery',
    )
  );
}


/**
 * Custom Admin Columns for Slider
 */
add_filter('manage_slider_posts_columns', 'halim_slider_columns');
function halim_slider_columns($columns) {
  $columns = array(
    'cb' => $columns['cb'],
    'title' => __('Title', 'halim'),
    'image' => __('Image', 'halim'),
    'sub_title' => __('Subtitle', 'halim'),
    'date' => __('Date', 'halim'),
  );
  return $columns;
}

add_action('manage_slider_posts_custom_column', 'halim_slider_column', 10, 2);
function halim_slider_column($column, $post_id) {
  // image column
  if ('image' === $column) {
    echo get_the_post_thumbnail($post_id, [50, 50]);
  }
  // subtitle column
  if ('sub_title' === $column) {
    echo get_field('sub_title');
  }
}
